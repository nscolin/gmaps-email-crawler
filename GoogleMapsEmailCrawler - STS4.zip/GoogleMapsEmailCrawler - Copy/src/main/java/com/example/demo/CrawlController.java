package com.example.demo;

import java.io.IOException;
import java.util.*;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class CrawlController {

	/**
	 * Main client interface to make Google Maps API requests 
	 * @return String of HTML data, form of input fields 
	 */
	@GetMapping("/request")
	public String defineRequest() {
		return Response.form();
	}
	
	/**
	 * Data to complete RequestEntity of HTTP Post request to Google Maps API endpoint
	 * @param maxResultCount Number of search results displayed (1-20)
	 * @param zipcode A valid 5-digit US zipcode 
	 * @param radius Search radius in miles (converted into m for API request)
	 * @param apiKey Secret Google Maps API key (client-specific)
	 * @param includedTypes 
	 * @return Response is an HTML webpage to format emails for easy selection 
	 */
	@PostMapping("/request")
	public String makeRequest(@RequestParam String maxResultCount,
						   @RequestParam String zipcode,
						   @RequestParam String radius,
						   @RequestParam String apiKey,
						   @RequestParam List<String> includedTypes) {
		
		// Zipcode parameter is converted into Coordinates with Gmaps Geocoding API
		List<String> coordinates = ZipcodeToCoordinates.convert(zipcode, apiKey);
		
		String latitude = coordinates.remove(0);
		String longitude = coordinates.remove(0);

		
		
		// Convert radius from miles to meters for Google Maps API call
		final double MILES_TO_METERS = 1609.34;
		double mRadius = Integer.parseInt(radius);
		mRadius = mRadius * MILES_TO_METERS;
		
		// Convert List<String> includedTypes into a JSON array string
		String includedTypesJson = "";
		try {
			includedTypesJson = new ObjectMapper().writeValueAsString(includedTypes);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// may consider csv for includedTypes field
		String requestBody = String.format("{'includedTypes': %s, 'maxResultCount': %s, 'locationRestriction': {'circle': {'center': {'latitude': %s, 'longitude': %s}, 'radius': %s}}}",
	            includedTypesJson, maxResultCount, latitude, longitude, mRadius);

		// Define the headers
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
	    headers.set("X-Goog-Api-Key", apiKey);
	    headers.set("X-Goog-FieldMask", "places.displayName,places.primaryType,places.types,places.websiteUri");
		
	    RestTemplate restTemplate = new RestTemplate();

	    
	    // Create the request entity with headers and body
	    HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);

	    // Define the endpoint URL
	    String endpoint = "https://places.googleapis.com/v1/places:searchNearby";

	    // Make the HTTP POST request
	    ResponseEntity<String> response = restTemplate.exchange(endpoint, HttpMethod.POST, requestEntity, String.class);

	    // Handle the response accordingly
	    String json = response.getBody();
	    //return json;
	    
	    ObjectMapper mapper = new ObjectMapper();
	    
	    List<String> websites = new ArrayList<>();
	        
	    try {
			MyWrapper myWrapper = mapper.readValue(json, MyWrapper.class);
			
			Place[] places = myWrapper.getPlaces();
			
			for (Place place : places) {
				websites.add(place.getWebsiteUri());
			}
		} catch (IOException e) {
            System.err.println("Error reading JSON from file or deserializing: " + e.getMessage());
        }
			
	   
			EmailCrawler crawler = new EmailCrawler();
			
			List<String> emails = crawler.crawlAll(websites);

			 	
			return Response.render(emails);
	}
	
	
	/**
	 * GetMapping at /zip endpoint accepts the html fields zipcode and Google Maps API key 
	 * @return
	 */
	@GetMapping("/zip")
	public String getZip() {
		return "<p>Enter your zipcode to convert to lat. long. coordinates</p>" +
				"<form method='post' action='/zip'>" +
				"<input type='text' name='zipcode' placeholder='zipcode'><br>" +
				"<input type='password' name='apiKey' placeholder='Enter API Key'><br>" +
				"<button type='submit'>Submit</button>" +
				"</form>";
	}
	
	/**
	 * The PostMapping /zip endpoint demonstrates the basic functionality of the Geocoding API call 
	 * converting zipcode into coordinates.
	 * @param zipcode Accepts a valid 5-digit US zipcode
	 * @param apiKey Google Maps API key used in API call
	 * @return The city or town coordinates in {"lat", "lng"}
	 */
	@PostMapping("/zip")
	public List<String> postZip(@RequestParam String zipcode, 
						  @RequestParam String apiKey) {
		
		// List<String> contains two elements: latitude, longitude
		return ZipcodeToCoordinates.convert(zipcode, apiKey);
	}
	
}
