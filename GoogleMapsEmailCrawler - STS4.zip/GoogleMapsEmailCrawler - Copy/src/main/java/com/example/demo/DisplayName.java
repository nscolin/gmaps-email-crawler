package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DisplayName {
    @JsonProperty("text")
    private String text;

    @JsonProperty("languageCode")
    private String languageCode;

    // Getters and setters
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
}



