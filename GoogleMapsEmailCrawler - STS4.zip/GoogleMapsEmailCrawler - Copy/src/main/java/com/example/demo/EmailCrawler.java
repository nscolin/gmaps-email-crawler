package com.example.demo;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.web.client.RestTemplate;
import java.util.*;

import java.util.regex.*;
import java.util.stream.Collectors;
import java.net.URI;
import java.net.URISyntaxException;

public class EmailCrawler {

    private RestTemplate restTemplate;
    private List<String> emails;
    private Set<String> crawledUrls;

    public EmailCrawler() {
    	
        this.restTemplate = new RestTemplate();
        this.emails = new ArrayList<>();
        this.crawledUrls = new HashSet<>();
        
    }


	// Method to find email addresses in the HTML response
    public static String findEmail(String htmlResponse) {
        // Regular expression to match email addresses
        String regex = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(htmlResponse);

        // Check if any email addresses are found
        if (matcher.find()) {
        	System.out.println("Email found in body: " + matcher.group());
            return matcher.group();
        } else {
            return null;
        }
    }

    // Method to find mailto: links in the HTML response
    public static String findMailtoLink(String htmlResponse) {
        // Regular expression to match mailto: links
        String regex = "mailto:[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(htmlResponse);

        // Check if any mailto: links are found
        if (matcher.find()) {
        	System.out.println("Email found in href: " + matcher.group());
            return matcher.group();
        } else {
            return null;
        }
    }

    // Method to extract domain from URL
    public static String extractDomain(String url) {
        try {
        	URI uri = new URI(url);
            String domain = uri.getHost();
            return "https://" + domain; // Assuming we want to crawl HTTP for simplicity
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return "domain not found";
        }
    }
    // Returns true if hyperlink is an internal link
    private boolean isInternalLink(String url, String domain) {
    	return url.startsWith(domain);
    }
    
    // Removes duplicate emails from List before returned to clients
    public static List<String> removeDuplicates(List<String> emails) {
        // Convert the list to a Set to automatically remove duplicates
        Set<String> uniqueEmails = new HashSet<>(emails);
        // Convert the Set back to a List
        return uniqueEmails.stream().collect(Collectors.toList());
    }
   
    
    /**
     * Controls the email crawler. Calls the domain, then recursively calls its subpages. 
     * @param websites List of websites deserialized from Post Request to Nearby Search API
     * @return List of emails found by crawling all of the websites
     */
    public List<String> crawlAll(List<String> websites) {
    	try {
    		
    		while(!websites.isEmpty()) {
    			
    			String url = websites.remove(0);
    			String domain = extractDomain(url);
    			
    			// check homepage for email
    			crawl(domain, false);
    			
    			// recursively call crawl method on subpages of homepage.
    			crawl(domain, true);   			
    		}
    		
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    	return removeDuplicates(emails);
    }
    
    /**
     * Crawls websites with recursive trigger for emails and adds to List
     * @param website String url to be crawled
     * @param recursive Boolean variable to trigger search with Jsoup and recursive crawl of subpages
     */
    public void crawl(String website, boolean recursive) {
    	
    	try {
    		String html = restTemplate.getForObject(website, String.class);
    		
    		if (recursive) {
    			 Document doc = Jsoup.parse(html);
                 Elements links = doc.select("a[href]");
                 
                 for (Element link : links) {
                     String subUrl = link.absUrl("href");
                     if (isInternalLink(subUrl, website) && !crawledUrls.contains(subUrl)) {
                    	 crawledUrls.add(subUrl);
                    	 crawl(subUrl, false); 
                 }
    		}
    		}
    		String email = findEmail(html);
    		String href = findMailtoLink(html);
    		
    		if (email != null) {
    			emails.add(email);
    		} else if (href != null) {
    			emails.add(href);
    		} 
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    }
    
    
}

