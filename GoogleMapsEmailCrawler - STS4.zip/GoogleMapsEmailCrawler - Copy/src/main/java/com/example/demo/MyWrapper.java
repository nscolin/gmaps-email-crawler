package com.example.demo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MyWrapper {
    @JsonProperty("places")
    private Place[] places;

    public Place[] getPlaces() {
        return places;
    }

    public void setPlaces(Place[] places) {
        this.places = places;
    }
    // Getters and setters
}