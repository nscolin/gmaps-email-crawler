package com.example.demo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Place {


    @JsonProperty("websiteUri")
    private String websiteUri;

    @JsonProperty("displayName")
    private DisplayName displayName;


    // Constructors, getters, and setters
    // Constructors, getters, and setters

    public Place() {
    	
    }

    public String getName() {
        return displayName != null ? displayName.getText() : null;
    }
    public String getWebsiteUri() {
        return websiteUri;
    }


    public DisplayName getDisplayName() {
        return displayName;
    }


   
}
