package com.example.demo;

import java.util.List;

public class Response {

	public static String form() {
		return "<form method='post' action='/request'>" +		
				"<input type='text' name='maxResultCount' placeholder='Results to display'><br>" +
				"<input type='text' name='zipcode' placeholder='Enter zipcode (US)'><br>" +
				"<input type='text' name='radius' placeholder='Enter radius (miles)'><br>" +
				"<input type='password' name='apiKey' placeholder='Paste Google API Key (Secret)'><br>" +
				"<select name='includedTypes' multiple>" +
		        	"<option value='liquor_store'>Liquor Store</option>" +
		        	"<option value='convenience_store'>Convenience Store</option>" +
		        	"<option value='barber_shop'>Barber Shop</option>" +
		        	"<option value='beauty_salon'>Beauty Salon</option>" +
		        	"<option value='cemetery'>Cemetery</option>" +
		        	"<option value='child_care_agency'>Child Care Agency</option>" +
		        	"<option value='consultant'>Consultant</option>" +
		        	"<option value='courier_service'>Courier Service</option>" +
		        	"<option value='electrician'>Electrician</option>" +
		        	"<option value='florist'>Florist</option>" +
		        	"<option value='funeral_home'>Funeral Home</option>" +
		        	"<option value='hair_care'>Hair Care</option>" +
		        	"<option value='hair_salon'>Hair Salon</option>" +
		        	"<option value='insurance_agency'>Insurance Agency</option>" +
		        	"<option value='laundry'>Laundry</option>" +
		        	"<option value='lawyer'>Lawyer</option>" +
		        	"<option value='locksmith'>Locksmith</option>" +
		        	"<option value='moving_company'>Moving Company</option>" +
		        	"<option value='painter'>Painter</option>" +
		        	"<option value='plumber'>Plumber</option>" +
		        	"<option value='real_estate_agency'>Real Estate Agency</option>" +
		        	"<option value='roofing_contractor'>Roofing Contractor</option>" +
		        	"<option value='storage'>Storage</option>" +
		        	"<option value='tailor'>Tailor</option>" +
		        	"<option value='telecommunications_service_provider'>Telecommunications Service Provider</option>" +
		        	"<option value='travel_agency'>Travel Agency</option>" +
		        	"<option value='veterinary_care'>Veterinary Care</option>" +

		        "</select><br>" +
				"<button type='submit'>Submit</button>" +
				"<br>" +
           "</form>";
	}
	
	public static String render(List<String> emails) {
		
		StringBuilder html = new StringBuilder();
		html.append("<h1>Google Maps Email Crawler App</h1>");
		html.append("<h3>Your search returned the following businesses emails:</h3>");
		html.append("<form id='emailForm' method='post' action='/page'>");
		html.append("<button type='button' onclick='selectAll()'>Select all</button><br>");

		for (String email : emails) {
		    html.append("<input type='checkbox' id='").append(email).append("' name='email' value='").append(email).append("'>");
		    html.append("<label for='").append(email).append("'>").append(email).append("</label><br>");
		}

		html.append("<a href='#' onclick='sendEmail()'>Send email</a>");
		html.append("</form>");

		html.append("<script>");
		html.append("var selectAllState = false;");
		html.append("function selectAll() {");
		html.append("  var checkboxes = document.querySelectorAll('input[type=\"checkbox\"]');");
		html.append("  checkboxes.forEach(function(checkbox) {");
		html.append("    checkbox.checked = !selectAllState;");
		html.append("  });");
		html.append("  selectAllState = !selectAllState;");
		html.append("}");
		html.append("function sendEmail() {");
		html.append("  var checkboxes = document.querySelectorAll('input[type=\"checkbox\"]:checked');");
		html.append("  var emails = [];");
		html.append("  checkboxes.forEach(function(checkbox) {");
		html.append("    emails.push(checkbox.value);");
		html.append("  });");
		html.append("  if (emails.length > 0) {");
		html.append("    var mailtoLink = 'mailto:?bcc=' + emails.join(',');");
		html.append("    window.location.href = mailtoLink;");
		html.append("  } else {");
		html.append("    alert('Please select at least one email.'); ");
		html.append("  }");
		html.append("}");
		html.append("</script>");

		return html.toString();
	}
}
