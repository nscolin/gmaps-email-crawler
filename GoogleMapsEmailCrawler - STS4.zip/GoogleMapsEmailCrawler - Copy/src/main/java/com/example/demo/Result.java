package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.*;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Result {
    
    private Geometry geometry;

    public Geometry getGeometry() {
        return geometry;
    }

    public void setGeometry(Geometry geometry) {
        this.geometry = geometry;
    }
}

@JsonIgnoreProperties(ignoreUnknown = true)
class Geometry {

    private Location location;

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}

@JsonIgnoreProperties(ignoreUnknown = true)
class Location {

    private String lat;
    private String lng;

    @JsonProperty("lat")
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    @JsonProperty("lng")
    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

 // Convert Location object to List<String>
    public List<String> toList() {
        List<String> list = new ArrayList<>();
        list.add(lat);
        list.add(lng);
        return list;
    }
}	
