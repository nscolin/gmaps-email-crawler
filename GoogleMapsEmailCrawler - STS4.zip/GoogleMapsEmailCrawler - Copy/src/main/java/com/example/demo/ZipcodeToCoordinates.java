package com.example.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;



public class ZipcodeToCoordinates {

	private static final String GOOGLE_GEOCODING_API_URL = "https://maps.googleapis.com/maps/api/geocode/json";
	
	public static List<String> convert(String zip, String apiKey) {
		RestTemplate restTemplate = new RestTemplate();
		
		String apiUrl = GOOGLE_GEOCODING_API_URL + "?address=" + zip + "&key=" + apiKey;
        String jsonString = restTemplate.getForObject(apiUrl, String.class);
        
        try {
            return getLocationArray(jsonString);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static List<String> getLocationArray(String jsonString) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        GeocodingResponse response = objectMapper.readValue(jsonString, GeocodingResponse.class);

        // Assuming there's only one result in the response
        if (response.getResults() != null && !response.getResults().isEmpty()) {
            Result result = response.getResults().get(0);
            return result.getGeometry().getLocation().toList();
   
        }

        return null;
    }
}
